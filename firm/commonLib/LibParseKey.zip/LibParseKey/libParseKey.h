//#ifndef _LIB_PARSE_KEY_H_
//#define _LIB_PARSE_KEY_H_

void InitParseKeyModule();
int ParseKey(char ans[][6]);

//#endif
